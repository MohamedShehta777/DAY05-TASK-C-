﻿//>> part01:
#region Problem 1 - Divide Two Numbers
static void DivideNumbers()
{
    try
    {
        Console.Write("Enter first number: ");
        int num1 = int.Parse(Console.ReadLine());
        Console.Write("Enter second number: ");
        int num2 = int.Parse(Console.ReadLine());

        Console.WriteLine($"Result: {num1 / num2}");
    }
    catch (DivideByZeroException)
    {
        Console.WriteLine("Cannot divide by zero.");
    }
    finally
    {
        Console.WriteLine("Operation complete.");
    }
}
//The finally block ensures that a specific piece of code runs regardless of whether an exception is thrown or not. 
//It is typically used for cleanup tasks, such as closing files or releasing resources.


#endregion
#region Problem 2 - Test Defensive Code
static void TestDefensiveCode()
{
    int x, y;

    Console.Write("Enter a positive value for X: ");
    while (!int.TryParse(Console.ReadLine(), out x) || x <= 0)
    {
        Console.Write("Invalid input. Please enter a positive value for X: ");
    }

    Console.Write("Enter a value for Y (greater than 1): ");
    while (!int.TryParse(Console.ReadLine(), out y) || y <= 1)
    {
        Console.Write("Invalid input. Please enter a value for Y greater than 1: ");
    }

    Console.WriteLine($"X: {x}, Y: {y}");
}

//int.TryParse() prevents exceptions by returning false when the input is invalid, while int.Parse() would throw an exception if the input is not a valid integer. 
//TryParse() allows the program to handle invalid input gracefully without crashing.
#endregion
#region Problem 3 - Nullable Integer
static void NullableIntegerExample()
{
    int? nullableInt = null;

    int result = nullableInt ?? 10;

    Console.WriteLine($"The value of nullableInt is: {nullableInt}");
    Console.WriteLine($"The result with default value is: {result}");

    Console.WriteLine($"HasValue: {nullableInt.HasValue}");
    if (nullableInt.HasValue)
    {
        Console.WriteLine($"Value: {nullableInt.Value}");
    }
}

//When trying to access the Value property of a Nullable<T> variable that is null, a InvalidOperationException will occur, specifically with the message "Nullable object must have a value."
#endregion
#region Problem 4 - 1D Array Example
static void OneDArrayExample()
{
    int[] arr = new int[5];

    try
    {
        Console.WriteLine(arr[10]);
    }
    catch (IndexOutOfRangeException)
    {
        Console.WriteLine("Index out of bounds.");
    }
}
//It is necessary to check array bounds to avoid IndexOutOfRangeException. 
//Accessing an invalid index outside the bounds of the array results in an exception, which can crash the program if not handled correctly.
#endregion
#region Problem 5 - 3x3 Array Example
static void ThreeByThreeArray()
{
    int[,] array = new int[3, 3];

    for (int i = 0; i < 3; i++)
    {
        for (int j = 0; j < 3; j++)
        {
            Console.Write($"Enter value for position ({i}, {j}): ");
            array[i, j] = int.Parse(Console.ReadLine());
        }
    }

    Console.WriteLine("Sum of each row:");
    for (int i = 0; i < 3; i++)
    {
        int rowSum = 0;
        for (int j = 0; j < 3; j++)
        {
            rowSum += array[i, j];
        }
        Console.WriteLine($"Row {i + 1}: {rowSum}");
    }

    Console.WriteLine("Sum of each column:");
    for (int j = 0; j < 3; j++)
    {
        int colSum = 0;
        for (int i = 0; i < 3; i++)
        {
            colSum += array[i, j];
        }
        Console.WriteLine($"Column {j + 1}: {colSum}");
    }
}

//The GetLength(dimension) method is used to get the number of elements in a specific dimension of a multi-dimensional array. 
//For example, array.GetLength(0) returns the number of rows, and array.GetLength(1) returns the number of columns in a 2D array.
#endregion
#region Problem 6 - Jagged Array Example
static void JaggedArrayExample()
{
    int[][] jaggedArray = new int[3][];

    for (int i = 0; i < 3; i++)
    {
        Console.Write($"Enter number of elements for row {i + 1}: ");
        int numElements = int.Parse(Console.ReadLine());
        jaggedArray[i] = new int[numElements];

        for (int j = 0; j < numElements; j++)
        {
            Console.Write($"Enter value for row {i + 1}, column {j + 1}: ");
            jaggedArray[i][j] = int.Parse(Console.ReadLine());
        }
    }

    Console.WriteLine("Jagged Array:");
    for (int i = 0; i < jaggedArray.Length; i++)
    {
        foreach (var value in jaggedArray[i])
        {
            Console.Write(value + " ");
        }
        Console.WriteLine();
    }
}

//In a jagged array, each row is an independent array, meaning the rows can have different lengths, and the memory is allocated for each row separately.
//In contrast, a rectangular array (multi-dimensional array) allocates memory contiguously for all elements, making it a more memory-efficient option when all rows need to have the same number of elements.
#endregion
#region Problem 7 - Nullable Reference Type Example
static void NullableReferenceTypeExample()
{
    string? nullableString = null;

    Console.Write("Enter a string (or leave blank): ");
    string input = Console.ReadLine();
    nullableString = string.IsNullOrEmpty(input) ? null : input;

    string nonNullableString = nullableString!;

    Console.WriteLine($"Nullable string value: {nullableString}");
    Console.WriteLine($"Non-nullable string value (with '!'): {nonNullableString}");
}

//Nullable reference types were introduced to help developers distinguish between references that can be null and those that cannot.
//This provides better null-safety and reduces NullReferenceException errors by making the nullability of references explicit in the code.


#endregion
#region Problem 8 - Boxing and Unboxing
static void BoxingAndUnboxing()
{
    int num = 42;

    object obj = num;

    try
    {
        int unboxedValue = (int)obj;
        Console.WriteLine($"Unboxed value: {unboxedValue}");
    }
    catch (InvalidCastException)
    {
        Console.WriteLine("Invalid cast exception.");
    }
}

//Boxing and unboxing involve converting a value type to a reference type and vice versa. 
//This can have a performance impact, as boxing involves allocating memory on the heap, and unboxing requires type-checking and casting. Frequent boxing and unboxing operations can lead to increased memory usage and slower execution.


#endregion
#region Problem 9 - SumAndMultiply Method
static void SumAndMultiply(int x, int y, out int sum, out int product)
{
    sum = x + y;
    product = x * y;
}

static void CallSumAndMultiply()
{
    int x = 5, y = 10;
    int sum, product;

    SumAndMultiply(x, y, out sum, out product);

    Console.WriteLine($"Sum: {sum}, Product: {product}");
}

//parameters must be initialized inside the method because they do not have a default value when passed into the method.
//The caller is required to receive a value, so the method must assign a value to the out parameter before returning.
#endregion
#region Problem 10 - Optional Parameters and Named Parameters
static void PrintStringMultipleTimes(string text, int times = 5)
{
    for (int i = 0; i < times; i++)
    {
        Console.WriteLine(text);
    }
}

static void CallPrintStringMultipleTimes()
{
    PrintStringMultipleTimes("Hello", times: 3);
}

//Optional parameters must appear at the end because, in C#, arguments are matched to parameters from left to right.
//If optional parameters were placed before required ones, it would be impossible to call the method without explicitly specifying values for optional parameters.


#endregion
#region Problem 11 - Nullable Integer Array
static void NullableArrayExample()
{
    int?[] nullableArray = new int?[5];

    int? firstElement = nullableArray?[0];
    Console.WriteLine($"First element (nullable): {firstElement ?? 0}");
}

//The null propagation operator (?.) prevents NullReferenceException by checking if the object is null before accessing its members.
//If the object is null, the operation is short-circuited, and no exception is thrown.
#endregion
#region Problem 12 - Switch Expression
static void DayToNumber()
{
    Console.Write("Enter a day of the week: ");
    string day = Console.ReadLine()?.ToLower();

    int dayNumber = day switch
    {
        "monday" => 1,
        "tuesday" => 2,
        "wednesday" => 3,
        "thursday" => 4,
        "friday" => 5,
        "saturday" => 6,
        "sunday" => 7,
        _ => 0
    };

    Console.WriteLine($"The corresponding number for {day} is: {dayNumber}");
}

//A switch expression is preferred over a traditional if statement when there are multiple possible values for a variable.
//It is more concise and readable when dealing with multiple conditions that map to specific values or actions.


#endregion
#region Problem 13 - SumArray Method
static int SumArray(params int[] numbers)
{
    return numbers.Sum();
}

static void CallSumArray()
{
    int result = SumArray(1, 2, 3, 4, 5);
    Console.WriteLine($"The sum of the numbers is: {result}");
}

//The params keyword allows a variable number of arguments to be passed to a method, but it must be the last parameter in the method signature.
//You cannot have other parameters after the params parameter, and it can only be used with a single parameter in the method.


#endregion

//>> part02: 
#region Problem 1 - Print Numbers in a Range
static void PrintNumbersInRange()
{
    Console.Write("Enter a positive integer: ");
    int number = int.Parse(Console.ReadLine());

    for (int i = 1; i <= number; i++)
    {
        Console.Write(i + " ");
    }
    Console.WriteLine();
}
#endregion
#region Problem 2 - Multiplication Table
static void PrintMultiplicationTable()
{
    Console.Write("Enter an integer: ");
    int number = int.Parse(Console.ReadLine());

    for (int i = 1; i <= 12; i++)
    {
        Console.Write((number * i) + " ");
    }
    Console.WriteLine();
}
#endregion
#region Problem 3 - Even Numbers
static void PrintEvenNumbers()
{
    Console.Write("Enter a number: ");
    int number = int.Parse(Console.ReadLine());

    for (int i = 2; i <= number; i += 2)
    {
        Console.Write(i + " ");
    }
    Console.WriteLine();
}
#endregion
#region Problem 4 - Exponentiation
static void ComputeExponentiation()
{
    Console.Write("Enter base number: ");
    int baseNum = int.Parse(Console.ReadLine());

    Console.Write("Enter exponent: ");
    int exponent = int.Parse(Console.ReadLine());

    Console.WriteLine($"Result: {Math.Pow(baseNum, exponent)}");
}
#endregion
#region Problem 5 - Reverse Text String
static void ReverseString()
{
    Console.Write("Enter a string: ");
    string input = Console.ReadLine();
    char[] arr = input.ToCharArray();
    Array.Reverse(arr);
    Console.WriteLine($"Reversed string: {new string(arr)}");
}
#endregion
#region Problem 6 - Reverse Integer
static void ReverseInteger()
{
    Console.Write("Enter an integer: ");
    int input = int.Parse(Console.ReadLine());

    int reversed = 0;
    while (input != 0)
    {
        reversed = reversed * 10 + input % 10;
        input /= 10;
    }

    Console.WriteLine($"Reversed integer: {reversed}");
}
#endregion
#region Problem 7 - Longest Distance Between Matching Elements
static void LongestDistanceBetweenMatchingElements()
{
    Console.Write("Enter a series of integers separated by commas: ");
    int[] array = Console.ReadLine().Split(',').Select(int.Parse).ToArray();

    int maxDistance = 0;

    for (int i = 0; i < array.Length; i++)
    {
        for (int j = i + 1; j < array.Length; j++)
        {
            if (array[i] == array[j])
            {
                maxDistance = Math.Max(maxDistance, j - i);
            }
        }
    }

    Console.WriteLine($"Longest distance between matching elements: {maxDistance}");
}
#endregion












